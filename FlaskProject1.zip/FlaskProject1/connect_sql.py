import pymysql.cursors
import pymysql
import pandas as pd
from pandas import DataFrame
from sqlalchemy import create_engine
import sqlalchemy
from werkzeug.security import generate_password_hash,check_password_hash

class Sql():
    def __init__(self, name):
        self.config = {
            'host': '127.0.0.1',
            'port': 3306,  # MySQL默认端口
            'user': 'root',  # mysql默认用户名
            'password': 'rjgc555',
            'db': 'test',  # 数据库
            'charset': 'utf8mb4',
        }
        self.con = pymysql.connect(**self.config)
        self.sql_global = "select * from " + str(name)

    def read_database(self, name, head):
        try:
            with self.con.cursor() as cursor:
                cursor.execute(self.sql_global)
                result = cursor.fetchall()
        except Exception as e:
            raise e
        finally:
            df = pd.DataFrame(result)  # 转换成DataFrame格式,比较好处理
            df.columns = head
            cursor.close()
            return df

    #####data格式[("sss", "fsfe55","0"), ("ssps", "fsfe5590","0")]
    ##前面是用户名，后面是密码(用哈希加盐过的)
    def insert_database(self, name, data):
        cursor = self.con.cursor()
        # sql_insert = "insert into user_info(ID,PSD) values('liu','1234')"
        # 多条插入一起执行
        # rows = cursor.executemany("insert into user_info(ID, PSD) "
        #                                "values (%s, %s)",data)
        sql_insert = "insert into " + str(name) + "(username,password,root) values(%s,%s,%s)"  # 要插入的数据
        try:
            cursor.executemany(sql_insert, data)
            # 提交
            self.con.commit()
            cursor.execute(self.sql_global)
            result = cursor.fetchall()
        except Exception as e:
            #    # 错误回滚
            self.con.rollback()
        finally:
            cursor.close()

    ##data格式data = [("789", '1',"sss"), ("777777",'1',"ssps")]
    ##前面是密码(用哈希加盐过的)，后面是用户名
    def update_database(self, name, data):

        # 使用cursor()方法获取操作游标
        cursor = self.con.cursor()

        sql_update = "update " + str(name) + " set password = '%s' ,root = '%s' where username = '%s'"

        # try:
        for item in data:
            cursor.execute(sql_update % item)  # 像sql语句传递参数
        # cursor.executemany(sql_update, data)
        # 提交
        self.con.commit()
        cursor.execute(self.sql_global)
        # except Exception as e:
        # 错误回滚
        self.con.rollback()
        # finally:
        cursor.close()


    ###data格式data=[('sss')]用户名
    def delete_database(self, name, data):
        # self.con = pymysql.connect(**config)
        cursor = self.con.cursor()
        sql_delete = "delete from " + str(name) + " where username ='%s'"

        try:
            for item in data:
                cursor.execute(sql_delete % (item))  # 像sql语句传递参数
            # 提交
            self.con.commit()
            cursor.execute(self.sql_global)
        except Exception as e:
            # 错误回滚
            self.con.rollback()
        finally:
            pass
            cursor.close()

    def end(self):
        self.con.close()


# sql = Sql('user_info')




head1 = ['username', 'password', 'root']
head2 = ['REPORT_NUM', 'EVENT_PROPERTY_NAME', 'EVENT_TYPE_ID', 'EVENT_TYPE_NAME', 'EVENT_SRC_NAME',
         'DISTRICT_ID', 'INTIME_ARCHIVE_NUM', 'SUB_TYPE_ID', 'DISTRICT_NAME', 'COMMUNITY_ID', 'REC_ID',
         'STREET_ID', 'OVERTIME_ARCHIVE_NUM', 'OPERATE_NUM', 'DISPOSE_UNIT_ID', 'STREET_NAME', 'CREATE_TIME',
         'EVENT_SRC_ID', 'INTIME_TO_ARCHIVE_NUM', 'SUB_TYPE_NAME',
         'EVENT_PROPERTY_ID', 'OCCUR_PLACE', 'COMMUNITY_NAME', 'DISPOSE_UNIT_NAME',
         'MAIN_TYPE_NAME', 'MAIN_TYPE_ID']
# connect_info = 'mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8'.format('root', 'rjgc555', 'localhost', '3306', 'test')  #1
# engine = create_engine(connect_info)
# sql_cmd = "SELECT * FROM project_data"
# df = pd.read_sql(sql=sql_cmd, con=engine)
# print(df)
# password = '77777788'
# Hash_pass = generate_password_hash('password')
# a = []
# a.append((Hash_pass, '1','lc'))
# password = '111188'
# Hash_pass = generate_password_hash('password')
# # print(type(Hash_pass))
# a.append((Hash_pass,'1','lqq'))
# password = '789'
# Hash_pass = generate_password_hash('password')
# a.append((Hash_pass, '1','wjd'))
# password = '777777'
# Hash_pass = generate_password_hash('password')
# a.append((Hash_pass, '1','xjh'))
# password = '78780'
# Hash_pass = generate_password_hash('password')
# a.append((Hash_pass, '1','xwy'))
# print(a)
# sql.update_database('user_info', a)




# # print(d['username'])
# print(d)
# print('-----------------')
# data = [('xxx', '000', '0'), ('yui', '111', '0')]
# sql.insert_database('user_info', data)
# d = sql.read_database('user_info', head)
# print(d)
# print('-----------------')
# data = [('xxx'), ('yui')]
# sql.delete_database('user_info', data)
# d = sql.read_database('user_info', head)
# print(d)
#
# print('-----------------')
# data = [('111188', '1', 'lqq'), ('77777788', '1', 'lc')]
#
# sql.update_database('user_info', data)
#d = sql.read_database('user_info', head1)

# print(d)
