function build_pie_nest(data){
var dom = document.getElementById("fouthcontainer");
var myChart = echarts.init(dom);
var app = {};

option = null;
app.title = '事件结办分析';

option = {
    tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
    },
    legend: {
        orient: 'vertical',
        x: 'left',
		data:data['all_type'],
        //data:['处置中','超期结办','按期结办','市容环卫','环保水务','市政设施','规土城建','安全隐患','文体旅游','教育卫生','组织人事','党纪政纪','党建群团','交通运输','劳动社保','民政服务','社区管理',''],
		// data:['直达','营销广告','搜索引擎','邮件营销','联盟广告','视频广告','百度','谷歌','必应','其他'],
    },
	toolbox: {
			show : true,
			feature : {
				mark : {show: true},
				dataView : {show: true, readOnly: false},
				magicType : {
					show: true,
					type: ['pie', 'funnel']
				},
				restore : {show: true},
				saveAsImage : {show: true},
				myTool:
				{
					show: true,
					title: 'back',
					icon:'image://http://echarts.baidu.com/images/favicon.png',
					onclick: function()
					{
						myChart.setOption(option);
					}
				}
			}
		},
		calculable : true,
    series: [
        { 
            name:'处置情况',
            type:'pie',
            selectedMode: 'single',
            radius: [0, '30%'],
			minAngle:5,
            label: {
                normal: {
                    show: false,
                }
            },
            labelLine: {
                normal: {
                    show: false
                }
            },
			data:data["inner_type"]
            // data:[
            //     {value:335, name:'直达', selected:true},
            //     {value:679, name:'营销广告'},
            //     {value:1548, name:'搜索引擎'}
            // ]
        },
        {
            name:'问题类型',
            type:'pie',
            radius: ['40%', '55%'],
            label: {
                normal: {
                    formatter: '{a|{a}}{abg|}\n{hr|}\n  {b|{b}：}{c}  {per|{d}%}  ',
                    backgroundColor: '#eee',
                    borderColor: '#aaa',
                    borderWidth: 1,
                    borderRadius: 4,
                    // shadowBlur:3,
                    // shadowOffsetX: 2,
                    // shadowOffsetY: 2,
                    // shadowColor: '#999',
                    // padding: [0, 7],
                    rich: {
                        a: {
                            color: '#999',
                            lineHeight: 22,
                            align: 'center'
                        },
                         abg: {
                             backgroundColor: '#333',
                             width: '100%',
							 align: 'right',
                             height: 22,
                             borderRadius: [4, 4, 0, 0]
                         },
                        hr: {
                            borderColor: '#aaa',
                            width: '100%',
                            borderWidth: 0.5,
                            height: 0
                        },
                        b: {
                            fontSize: 16,
                            lineHeight: 33
                        },
                        per: {
                            color: '#eee',
                            backgroundColor: '#334455',
                            padding: [2, 4],
                            borderRadius: 2
                        }
                    }
                }
            },
			data:data["outer_type"]
            // data:[
            //     {value:335, name:'直达'},
            //     {value:310, name:'邮件营销'},
            //     {value:234, name:'联盟广告'},
            //     {value:135, name:'视频广告'},
            //     {value:1048, name:'百度'},
            //     {value:251, name:'谷歌'},
            //     {value:147, name:'必应'},
            //     {value:102, name:'其他'}
            // ]
        }
    ]
};;
if (option && typeof option === "object") {
    myChart.setOption(option, true);
	function eConsole(param) {
	       if (typeof param.seriesIndex != 'undefined') {
	         if (param.type == 'click') {       //判断事件类型：点击
	            //写法一：获取饼图散区个数,按照图例获取 
	           var peiLenght= option.legend.data.length;
	           //写法二：获取饼图散区个数,按照series中data获取
	           //var peiLenght= option.series[0].data.length;
	
	           for(var i=0;i<peiLenght;i++){
	             //seriesIndex==0：选择内环饼图；param.dataIndex==i：散区
	             if(param.seriesIndex==0&&param.dataIndex==i){  
	               if(i==0){
	                 var option_1 = myChart.getOption();
	                 option_1.series[1].name='处置中';
	                 //option_1.series[1].color=['#205E3F','#16DA69','red'],
	                 option_1.series[1].data=data['处置中'];
					 // [
	     //               {value:10,name:'市容'},
	     //               {value:16,name:'环境'},
	     //               {value:12,name:'市政'},
					 //   {value:15,name:'市政2'},
					 //   {value:7,name:'市政3'},
	     //             ];
	                 myChart.setOption(option_1);
	               }else if(i==1){
	                 var option_2 = myChart.getOption();
	                 option_2.series[1].name='超期结办';
	                 //option_2.series[1].color=['#16DA69','#205E3F','red'],
	                 option_2.series[1].data=data['超期结办'];
					 // [
	     //                {value:20,name:'市容'},
	     //                {value:26,name:'环境'},
						// {value:6,name:'市政'},
	     //             ];
	                 myChart.setOption(option_2);
	               }else if(i==2){
	                 var option_3 = myChart.getOption();
	                 option_3.series[1].name='按期结办';
	                 //option_3.series[1].color=['blue','pink','red'],
	                 option_3.series[1].data=data['按期结办'];

					 // [
	     //                {'value':30,'name':'市容'},
	     //                {'value':24,'name':'市政'},
						// {'value':500,'name':'环境2'},
						// {'value':100,'name':'环境3'},
						// {'value':2,'name':'环境4'},
						// {'value':2,'name':'环境4'},
	     //             ];
	                 myChart.setOption(option_3);
	               }
	             }
	           }
	         }
	       }
	     }
	    myChart.on("click", eConsole);

}
	
}