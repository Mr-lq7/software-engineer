function get_al(){
	new slider({id:'slider'});
	function  Askwarning(){
		    var logoutdate={
				'order':1
			};
		    $.ajax({
			url:'http://127.0.0.1:5000/logout/',//后台数据库接口
			type:'POST',
			contentType:'application/json;charset=UTF-8',
			data:JSON.stringify(logoutdate), //数据，json字符串
			success:function(data){
				console.log('成功');
				data = eval(data);
				if(data){
					console.log(data);
					Alert(data);
					build_p(data['alert'].length);
					new slider({id:'slider'});
				}
				
			},
			error : function(){
				console.log('失败');
			},
			 	});
			 }
}

//setTimeout(get_alstr(),2000);
