var inputDate={"time1":{year: 2018, month: 10, day: 30},"time2":{year: 2018, month: 10, day: 30}};
var inputDatetmp={"time1":{year: 2018, month: 10, day: 30},"time2":{year: 2018, month: 10, day: 30}};
//var getday1=inputDate;
var getday2=inputDate;
var getday3=inputDate;
var getday4=inputDate;
var getday5=inputDate;
lay('#version').html('-v'+ laydate.v);
		//限定可选日期
		laydate.render({
		    elem: '#test1'
		    ,range: true
			,btns: ['confirm']
			,value: '2018-10-30 - 2018-10-30' 
			,max: '2018-10-30'
			,theme: 'molv'
			,done: function(value, date, endDate){
				var day={};
				var day_end={};
				day["year"]=date.year;
				day["month"]=date.month;
				day["day"]=date.date;

				inputDatetmp["time1"]=day; //得到日期时间对象：{year: 2018, month: 10, date: 30}
				day_end["year"]=endDate.year;
				day_end["month"]=endDate.month;
				day_end["day"]=endDate.date;
				inputDatetmp["time2"]=day_end; //得到日期时间对象：{year: 2018, month: 10, date: 30}
				getday1=inputDatetmp;
				console.log(getday1);
				getday2=getday1;
				getday3=getday1;
				getday4=getday1;
				getday5=getday1;

				 var s3edate = {	'order':3,
	 				'time1':getday3.time1,
	 				'time2':getday3.time2};

				 $.ajax({
					url:'http://127.0.0.1:5000/charts',//后台数据库接口
					type:'POST',
					contentType:'application/json;charset=UTF-8',
					data:JSON.stringify(s3edate), //数据，json字符串
					success:function(data){
						console.log('成功');
						var newdata = eval(data);
						if(newdata !== null)
							buildhistogram(newdata);
					},
					error : function(){
						console.log('失败');
					}

				 });


			}
		  });
		  laydate.render({
		      elem: '#test2'
		      ,range: true
		  	,btns: ['confirm']
		  	,value: '2018-10-30 - 2018-10-30' 
			,max: '2018-10-30'
			,theme: 'molv'
		  	,done: function(value, date, endDate){
		  		var day={};
		  		var day_end={};
		  		day["year"]=date.year;
		  		day["month"]=date.month;
		  		day["day"]=date.date;
		  		inputDatetmp["time1"]=day; //得到日期时间对象：{year: 2018, month: 10, date: 30}
		  		day_end["year"]=endDate.year;
		  		day_end["month"]=endDate.month;
		  		day_end["day"]=endDate.date;
		  		inputDatetmp["time2"]=day_end; //得到日期时间对象：{year: 2018, month: 10, date: 30}
		  		getday2=inputDatetmp;
				console.log(getday2);
		  	}
		    });
			laydate.render({
			    elem: '#test3'
			    ,range: true
				,btns: ['confirm']
				,value: '2018-10-30 - 2018-10-30'
				,max: '2018-10-30'
				,theme: 'molv'
				,done: function(value, date, endDate){
					var day={};
					var day_end={};
					day["year"]=date.year;
					day["month"]=date.month;
					day["day"]=date.date;
					inputDatetmp["time1"]=day; //得到日期时间对象：{year: 2018, month: 10, date: 30}
					day_end["year"]=endDate.year;
					day_end["month"]=endDate.month;
					day_end["day"]=endDate.date;
					inputDatetmp["time2"]=day_end; //得到日期时间对象：{year: 2018, month: 10, date: 30}
					getday3=inputDatetmp;
					console.log(getday3);
				}
			  });
			  laydate.render({
			      elem: '#test4'
			      ,range: true
			  	,btns: ['confirm']
			  	,value: '2018-10-30 - 2018-10-30'
				,max: '2018-10-30'
				,theme: 'molv'
			  	,done: function(value, date, endDate){
			  		var day={};
			  		var day_end={};
			  		day["year"]=date.year;
			  		day["month"]=date.month;
			  		day["day"]=date.date;
			  		inputDatetmp["time1"]=day; //得到日期时间对象：{year: 2018, month: 10, date: 30}
			  		day_end["year"]=endDate.year;
			  		day_end["month"]=endDate.month;
			  		day_end["day"]=endDate.date;
			  		inputDatetmp["time2"]=day_end; //得到日期时间对象：{year: 2018, month: 10, date: 30}
			  		getday4=inputDatetmp;
					console.log(getday4);
			  	}
			    });
				laydate.render({
				    elem: '#test5'
				    ,range: true
					,btns: ['confirm']
					,value: '2018-10-30 - 2018-10-30' 
					,max: '2018-10-30'
					,theme: 'molv'
					,done: function(value, date, endDate){
						var day={};
						var day_end={};
						day["year"]=date.year;
						day["month"]=date.month;
						day["day"]=date.date;
						inputDatetmp["time1"]=day; //得到日期时间对象：{year: 2018, month: 10, date: 30}
						day_end["year"]=endDate.year;
						day_end["month"]=endDate.month;
						day_end["day"]=endDate.date;
						inputDatetmp["time2"]=day_end; //得到日期时间对象：{year: 2018, month: 10, date: 30}
						getday5=inputDatetmp;
						console.log(getday5);
					}
				  });