"use strict";
var map = new BMap.Map("thridcontainer",{minZoom:4,maxZoom:20}); // 创建Map实例,设置地图允许的最小/大级别
map.centerAndZoom(new BMap.Point(114.360082,22.694206), 13);
map.enableScrollWheelZoom();
var opts = {
					width : 250,     // 信息窗口宽度
					height: 80,     // 信息窗口高度
					title : "社区信息：" , // 信息窗口标题
					enableMessage:true//设置允许信息窗发送短息
				   };
function heatMap(data_get){
		var heatdata=dealData(data_get);
		getBoundary(heatdata);
	}
function addClickHandler(content,marker){
				marker.addEventListener("click",function(e){
					openInfo(content,e)}
				);
			}
function  dealData(data_gettmp){
				var  community_xy={
							  "南布社区":{"x":114.3756073,"y":22.70534038},
							  "和平社区":{"x":114.3551041,"y":22.69710628},
							  "坪山社区":{"x":114.3554065,"y":22.69476592},
							  "汤坑社区":{"x":114.310038,"y":22.669347},				
							  "金沙社区":{"x":114.408079,"y":22.743131},
							  "江岭社区":{"x":114.3626752,"y":22.69195267},
							  "石井社区":{"x":114.386858,"y":22.697654},                                  
							  "六和社区":{"x":114.350474,"y":22.71613346},
							  "沙湖社区":{"x":114.326434,"y":22.679089},									
							  "老坑社区":{"x":114.3646738,"y":22.73285707},
							  "竹坑社区":{"x":114.39466,"y":22.71564698},
							  "秀新社区":{"x":114.381208,"y":22.746811},							
							  "沙田社区":{"x":114.4044441,"y":22.7617637},
							  "六联社区":{"x":114.349215,"y":22.749071},
							  "坪环社区":{"x":114.347237,"y":22.681559},								
							  "龙田社区":{"x":114.365941,"y":22.751031},									
							  "坑梓社区":{"x":114.383221,"y":22.746464},										
							  "沙坣社区":{"x":114.3778884,"y":22.69088931},
							  "田头社区":{"x":114.4108371,"y":22.69719664},
							  "田心社区":{"x":114.4219419,"y":22.70035215},
							  "碧岭社区":{"x":114.2956635,"y":22.67341994},
							  "信息缺失":{"x":114.350474,"y":22.71623346},
							  "金龟社区":{"x":114.406461,"y":22.663744},				
							  "马峦社区":{"x":114.338203,"y":22.644538}
				};
				var res = [];
				 for (var i = 0; i < data_gettmp.length; i++) {
						  var geoCoord = data_gettmp[i].name;
						  if(data_gettmp[i].value>=100) {
							  var data_tmp=data_gettmp[i].value * 0.01 + 10;
						  }else{
						  	  var data_tmp=data_gettmp[i].value * 0.01 + 5;
						  }
							  res.push([
								  community_xy[geoCoord].x,
								  community_xy[geoCoord].y,
								  data_tmp*2,
								  "社区:"+geoCoord+"<br>事件总数:"+data_gettmp[i].value
							  ]);
					  }
					return res;  
				}
	
function openInfo(content,e){
				var p = e.target;
				var point = new BMap.Point(p.getPosition().lng, p.getPosition().lat);
				var infoWindow = new BMap.InfoWindow(content,opts);  // 创建信息窗口对象 
				map.openInfoWindow(infoWindow,point); //开启信息窗口
			}
function getBoundary(heatdata){   
			var bdary = new BMap.Boundary();
			bdary.get("广东省深圳市坪山区", function(rs){       //获取行政区域
				map.clearOverlays();        //清除地图覆盖物       
				var count = rs.boundaries.length; //行政区域的点有多少个
				if (count === 0) {
					alert('未能获取当前输入行政区域');
					return ;
				}
	          var EN_JW = "180, 90;";         //东北角
	          var NW_JW = "-180,  90;";       //西北角
	          var WS_JW = "-180, -90;";       //西南角
	        var SE_JW = "180, -90;";        //东南角
	        //4.添加环形遮罩层
	        var ply1 = new BMap.Polygon(rs.boundaries[0] + SE_JW + SE_JW + WS_JW + NW_JW + EN_JW + SE_JW, { strokeColor: "none", fillColor: "#FFFAE8", fillOpacity:1, strokeOpacity: 0.5 }); //建立多边形覆盖物
	        map.addOverlay(ply1);  
	        var pointArray = [];
			for (var i = 0; i < count; i++) {
					var ply = new BMap.Polygon(rs.boundaries[i], { strokeWeight: 2, strokeColor: "#00f",fillColor: "" }); //建立多边形覆盖物
					map.addOverlay(ply);  //添加覆盖物
					pointArray = pointArray.concat(ply.getPath());
			}
			var data_info = heatdata;
			for(var i=0;i<data_info.length;i++){
					var content = data_info[i][3];
					var pt = new BMap.Point(data_info[i][0],data_info[i][1]);
					var myIcon = new BMap.Icon("../static/Image/heatmap.png",new BMap.Size(data_info[i][2],data_info[i][2]),{imageSize: new BMap.Size(data_info[i][2],data_info[i][2])},);
					var marker2 = new BMap.Marker(pt,{icon:myIcon});  // 创建标注
					map.addOverlay(marker2); 
					addClickHandler(content,marker2);
			}
			//map.setViewport(pointArray);    //调整视野
			});   
	}