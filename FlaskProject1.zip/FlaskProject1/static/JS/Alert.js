
function Alert(data)
{
	for(var i = 0; i < data['alert'].length; i++)
	{
		var str = function(i){
			var content = {};
			al_ele2.push(data['alert'][i]);
			al_img.push(data['alert'][i]['等级']);
			al_ele.push(data['alert'][i]);
		return 0;
	}(i);
		//al_string.push(str);
		
	}
	//console.log(al_img);
	//console.log(al_ele);
	//console.log(al_string);
}
