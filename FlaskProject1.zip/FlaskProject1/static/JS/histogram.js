function buildhistogram(data_input){
var Data=data_input;
console.log(Data);
var problem_type = Data['event_name'];
var count = problem_type.length;
delete Data.event_name;
var i = 0;
var all_kind = [];
for(var key in Data)
{
	var kind_detail = {};
	kind_detail.name = problem_type[i];
	kind_detail.type = 'bar';
	kind_detail.stack = '总量';
	kind_detail.label =  {
                normal: {
                    show: false,
                    position: 'insideRight'
				}
			},	
	kind_detail.data = Data[key];
	all_kind.push(kind_detail);
	i++;
}
var dom = document.getElementById("secondcontainer");
var myChart = echarts.init(dom);
var app = {};
option = null;
app.title = '各街道民生事件情况';

option = {
    tooltip : {
        trigger: 'axis',
        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
        }
    },
    legend: {
    		"icon":'circle',
			itemHeight:15,
    		orient: 'horizontal',
    		x: 'center',
    		y: 'bottom',
    		itemGap: 10,
			formatter: function (name) {
				  if (name.length > 4) {
					return name.slice(0,4) + '...';
				  }
				  else return name;
    },
    		//backgroundColor: '#F5F5F5',
    		// formatter: function (name) {
    		//             return echarts.format.truncateText(name, 50, '14px Microsoft Yahei', '…');
    		//         },
    		data:problem_type
            // data:function(p){
    		// 	var i = 1;
    		// 	var j = 6;
    		// 	while(p.length > i*j){
    		// 		p.splice(i*j-1,0, "");
    		// 		i += 1;
    		// 		j += 1;
    		// 		console.log(i);
    		// 		console.log(j);
    		// 	}
    		// 	p.splice((i-1)*(j-1)-1,1);
    		// 	return p;
    		// }(problem_type)
    		
    		// data: ['直接访问', '邮件营销','联盟广告','视频广告','搜索引擎']
        },
	toolbox: {
			x:'left',
			y:'top',
			show : true,
			feature : {
				mark : {show: true},
				dataView : {show: true, readOnly: false},
				magicType : {
					show: true,
					type: ['pie', 'funnel']
				},
				restore : {show: true},
				saveAsImage : {show: true}
			}
		},
		calculable : true,
    grid: {
        left: '3%',
        right: '5%',
        bottom: '15%',
        containLabel: true
    },
    xAxis:  {
       type: 'value',
    },
    yAxis: {
		type: 'category',
		data: ['碧岭街道','坑梓街道','龙田街道','马峦街道','坪山街道','石井街道','其他街道']
    },
	
	series:all_kind
	
    // series: [
    //     {
    //         name: '直接访问',
    //         type: 'bar',
    //         stack: '总量',
    //         label: {
    //             normal: {
    //                 show: true,
    //                 position: 'insideRight'
    //             }
    //         },
    //         data: [320, 302, 301, 334, 390, 330, 320]
    //     },
    //     {
    //         name: '邮件营销',
    //         type: 'bar',
    //         stack: '总量',
    //         label: {
    //             normal: {
    //                 show: true,
    //                 position: 'insideRight'
    //             }
    //         },
    //         data: [120, 132, 101, 134, 90, 230, 210]
    //     },
    //     {
    //         name: '联盟广告',
    //         type: 'bar',
    //         stack: '总量',
    //         label: {
    //             normal: {
    //                 show: true,
    //                 position: 'insideRight'
    //             }
    //         },
    //         data: [220, 182, 191, 234, 290, 330, 310]
    //     },
    //     {
    //         name: '视频广告',
    //         type: 'bar',
    //         stack: '总量',
    //         label: {
    //             normal: {
    //                 show: true,
    //                 position: 'insideRight'
    //             }
    //         },
    //         data: [150, 212, 201, 154, 190, 330, 410]
    //     },
    //     {
    //         name: '搜索引擎',
    //         type: 'bar',
    //         stack: '总量',
    //         label: {
    //             normal: {
    //                 show: true,
    //                 position: 'insideRight'
    //             }
    //         },
    //         data: [820, 832, 901, 934, 1290, 1330, 1320]
    //     }
    // ]
};
// myChart.showLoading();
// myChart.hideLoading();
if (option && typeof option === "object") {
    myChart.setOption(option, true);
}//endfunction
}