var homedivbegin = document.getElementById("pageone");
var chartdiv1 = document.getElementById("firstcharts");
var chartdiv2 = document.getElementById("secondcharts");
var chartdiv3 = document.getElementById("thirdcharts");
var chartdiv4 = document.getElementById("fouthcharts");
var backgroundbegin = document.getElementById("page1");
backgroundbegin.style.backgroundColor ="#796AEE";
homedivbegin.style.display = "block";
chartdiv1.style.display = "none";
chartdiv2.style.display = "none";
chartdiv3.style.display = "none";
chartdiv4.style.display = "none";
function DisplayStatus_home(){
	var background1 = document.getElementById("page1");
	var background2 = document.getElementById("page2");
	var background3 = document.getElementById("page3");
	var background4 = document.getElementById("page4");
	var background5 = document.getElementById("page5");
	var homedivbegin = document.getElementById("pageone");
	var chart1div = document.getElementById("firstcharts");
	var chart2div = document.getElementById("secondcharts");
	var chart3div = document.getElementById("thirdcharts");
	var chart4div = document.getElementById("fouthcharts");
	homedivbegin.style.display = "block";
	chart1div.style.display = "none";
	chart2div.style.display = "none";
	chart3div.style.display = "none";
	chart4div.style.display = "none";
	background1.style.backgroundColor ="#796AEE";
	background2.style.backgroundColor = "white";
	background3.style.backgroundColor = "white";
	background4.style.backgroundColor = "white";
	background5.style.backgroundColor = "white";
		}
function DisplayStatus_charts2(){
	var background1 = document.getElementById("page1");
	var background2 = document.getElementById("page2");
	var background3 = document.getElementById("page3");
	var background4 = document.getElementById("page4");
	var background5 = document.getElementById("page5");
	var homedivbegin = document.getElementById("pageone");
	var chart1div = document.getElementById("firstcharts");
	var chart2div = document.getElementById("secondcharts");
	var chart3div = document.getElementById("thirdcharts");
	var chart4div = document.getElementById("fouthcharts");
	homedivbegin.style.display = "none";
	chart1div.style.display = "none";
	chart2div.style.display = "block";
	chart3div.style.display = "none";
	chart4div.style.display = "none";
	background1.style.backgroundColor ="white";
	background2.style.backgroundColor = "white";
	background3.style.backgroundColor = "#796AEE";
	background4.style.backgroundColor = "white";
	background5.style.backgroundColor = "white";
	var s3edate = {	'order':3,
					'time1':getday.time1,
					'time2':getday.time2};

	$.ajax({
		url:'http://127.0.0.1:5000/charts',//后台数据库接口
		type:'POST',
		contentType:'application/json;charset=UTF-8',
		data:JSON.stringify(s3edate), //数据，json字符串
		success:function(data){
			console.log('成功');
			var newdata = eval(data);
			if(newdata !== null)
				buildhistogram(newdata);  //产生热力图
		},
		error : function(){
			console.log('失败');
		}
		
	});
		}
function DisplayStatus_charts3(){
	var background1 = document.getElementById("page1");
	var background2 = document.getElementById("page2");
	var background3 = document.getElementById("page3");
	var background4 = document.getElementById("page4");
	var background5 = document.getElementById("page5");
	var homedivbegin = document.getElementById("pageone");
	var chart1div = document.getElementById("firstcharts");
	var chart2div = document.getElementById("secondcharts");
	var chart3div = document.getElementById("thirdcharts");
	var chart4div = document.getElementById("fouthcharts");
	homedivbegin.style.display ="none" ;
	chart1div.style.display = "none";
	chart2div.style.display = "none";
	chart3div.style.display = "block";
	chart4div.style.display = "none";
	background1.style.backgroundColor ="white";
	background2.style.backgroundColor = "white";
	background3.style.backgroundColor = "white";
	background4.style.backgroundColor = "#796AEE";
	background5.style.backgroundColor = "white";
	var s4edate = {	'order':4,
					'time1':getday.time1,
					'time2':getday.time2};
	$.ajax({
		url:'http://127.0.0.1:5000/charts',//后台数据库接口
		type:'POST',
		contentType:'application/json;charset=UTF-8',
		data:JSON.stringify(s4edate), //数据，json字符串
		success:function(data){
			console.log('成功');
			var newdata = eval(data);
			if(newdata !== null)
				heatMap(newdata);  //产生热力图
		},
		error : function(){
			console.log('失败');
		}
		
	});
		}
function DisplayStatus_charts4(){
	var background1 = document.getElementById("page1");
	var background2 = document.getElementById("page2");
	var background3 = document.getElementById("page3");
	var background4 = document.getElementById("page4");
	var background5 = document.getElementById("page5");
	var homedivbegin = document.getElementById("pageone");
	var chart1div = document.getElementById("firstcharts");
	var chart2div = document.getElementById("secondcharts");
	var chart3div = document.getElementById("thirdcharts");
	var chart4div = document.getElementById("fouthcharts");
	homedivbegin.style.display = "none";
	chart1div.style.display = "none";
	chart2div.style.display = "none";
	chart3div.style.display = "none";
	chart4div.style.display = "block";
	background1.style.backgroundColor ="white";
	background2.style.backgroundColor = "white";
	background3.style.backgroundColor = "white";
	background4.style.backgroundColor = "white";
	background5.style.backgroundColor = "#796AEE";
	var s5edate = {	'order':5,
					'time1':getday.time1,
					'time2':getday.time2};
	$.ajax({
		url:'http://127.0.0.1:5000/charts',//后台数据库接口
		type:'POST',
		contentType:'application/json;charset=UTF-8',
		data:JSON.stringify(s5edate), //数据，json字符串
		success:function(data){
			console.log('成功');
			var newdata = eval(data);
			if(newdata !== null)
				build_pie_nest(newdata);
		},
		error : function(){
			console.log('失败');
		}
		
	});
		}