# from connect_sql import db
# #创建模型对象
#
#
# class User(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     username = db.Column(db.String(80), unique=True, nullable=False)
#     email = db.Column(db.String(120), unique=True, nullable=False)
#
#     def __repr__(self):
#         return '<User %r>' % self.username
#
#
# # 1.创建表
# db.create_all()
#
# # 2.增加记录
# admin = User(username='admin', email='admin@example.com')
# guest = User(username='guest', email='guest@example.com')
# db.session.add(admin)
# db.session.add(guest)
# db.session.commit()
#
# #3.查询记录,注意查询返回对象，如果查询不到返回None
# User.query.all() #查询所有
# User.query.filter_by(username='admin').first()#条件查询
# User.query.order_by(User.username).all()#排序查询
# User.query.limit(1).all()#查询1条
# User.query.get(id = 123)#精确查询
#
# # 4.删除
# user = User.query.get(id = 123)
# db.session.delete(user)
# db.session.commit()
# import pymysql
#
# 
# #读取数据
# cur.execute(sql)
# u = cur.fetchall()
# 
# conn.close()

# 向数据库里写入相应的数据(增)


# 从数据库里删除相应的数据(删)


# 修改数据库相应的数据(改)

import pymysql.cursors
import pymysql
import pandas as pd

# ------------------------------------读取数据库相应table信息
# 连接配置信息
# config = {
#     'host': '127.0.0.1',
#     'port': 3306,  # MySQL默认端口
#     'user': 'root',  # mysql默认用户名
#     'password': 'rjgc555',
#     'db': 'test',  # 数据库
#     'charset': 'utf8mb4',
# }
# # 创建连接
#con = pymysql.connect(**config)
# # # 执行sql语句
# # try:
# #     with con.cursor() as cursor:
# #         sql = "select * from user_info"
# #         cursor.execute(sql)
# #         result = cursor.fetchall()
# # except Exception as e:
# #     raise e
# # finally:
#        cursor.close()
# #     con.close()

# #
# # df = pd.DataFrame(result)  # 转换成DataFrame格式,比较好处理
# # print(df)
# # df.head()


from werkzeug.security import generate_password_hash,check_password_hash

#------------------------------
# -*- coding: utf-8 -*-
from datetime import datetime
from flask import request,jsonify,current_app
import pandas as pd
from dateutil.parser import parse
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
import connect_sql
from model import User

head2 = ['REPORT_NUM', 'EVENT_PROPERTY_NAME', 'EVENT_TYPE_ID', 'EVENT_TYPE_NAME', 'EVENT_SRC_NAME',
         'DISTRICT_ID', 'INTIME_ARCHIVE_NUM', 'SUB_TYPE_ID', 'DISTRICT_NAME', 'COMMUNITY_ID', 'REC_ID',
         'STREET_ID', 'OVERTIME_ARCHIVE_NUM', 'OPERATE_NUM', 'DISPOSE_UNIT_ID', 'STREET_NAME', 'CREATE_TIME',
         'EVENT_SRC_ID', 'INTIME_TO_ARCHIVE_NUM', 'SUB_TYPE_NAME',
         'EVENT_PROPERTY_ID', 'OCCUR_PLACE', 'COMMUNITY_NAME', 'DISPOSE_UNIT_NAME',
         'MAIN_TYPE_NAME', 'MAIN_TYPE_ID']

#sql = connect_sql.Sql('project_data')
# df = sql.read_database('project_data',head2)
# data = df.loc[0]
# print(data['SUB_TYPE_NAME'])
def create_token(api_user):
    '''
    生成token
    :param api_user:用户id
    :return: token
    '''


    #第一个参数是内部的私钥，这里写在共用的配置信息里了，如果只是测试可以写死
    #第二个参数是有效期(秒)
    s = Serializer(current_app.config["SECRET_KEY"],expires_in=3600)
    #接收用户id转换与编码
    token = s.dumps({"id":api_user})
    return token


# 基于上面的基础再导入用户的模型类


def verify_token(token):
    '''
    校验token
    :param token:
    :return: 用户信息 or None
    '''

    # 参数为私有秘钥，跟上面方法的秘钥保持一致
    s = Serializer(current_app.config["SECRET_KEY"])
    try:
        # 转换为字典
        data = s.loads(token)
        print(data)
    except Exception:
        return None
    # 拿到转换后的数据，根据模型类去数据库查询用户信息

    #user = User.query.get(data["id"])
    return None


# 在上面的基础上导入
# import functools
#
#
# def login_required(view_func):
#     @functools.wraps(view_func)
#     def verify_token(*args, **kwargs):
#         try:
#             # 在请求头上拿到token
#             token = request.headers["z-token"]
#         except Exception:
#             # 没接收的到token,给前端抛出错误
#             # 这里的code推荐写一个文件统一管理。这里为了看着直观就先写死了。
#             return jsonify(code=4103, msg='缺少参数token')
#
#         s = Serializer(current_app.config["SECRET_KEY"])
#         try:
#             s.loads(token)
#         except Exception:
#             return jsonify(code=4101, msg="登录已过期")
#
#         return view_func(*args, **kwargs)
#
#     return verify_token







