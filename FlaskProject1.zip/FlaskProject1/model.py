#coding:utf8

class User:
    def __init__(self,name=None,pwd=None,email=None,
                 age=None,birthday=None,face=None):
        self.name = name
        self.pwd = pwd
        self.email = email
        self.age = age
        self.birthday = birthday
        self.face = face