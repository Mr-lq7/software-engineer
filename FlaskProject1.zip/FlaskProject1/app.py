import os
from datetime import timedelta
from flask import Flask, url_for, render_template, request, redirect, session
from flask import jsonify
from flask import g
import json

import test111
from model import User
import process_data
import connect_sql

app = Flask(__name__)
# ctx = app.app_context()
# ctx.push()

app.config['SECRET_KEY'] = os.urandom(24)
#app.secret_key(os.urandom(24))
head1 = ['username', 'password', 'root']
head2 = ['REPORT_NUM', 'EVENT_PROPERTY_NAME', 'EVENT_TYPE_ID', 'EVENT_TYPE_NAME', 'EVENT_SRC_NAME',
         'DISTRICT_ID', 'INTIME_ARCHIVE_NUM', 'SUB_TYPE_ID', 'DISTRICT_NAME', 'COMMUNITY_ID', 'REC_ID',
         'STREET_ID', 'OVERTIME_ARCHIVE_NUM', 'OPERATE_NUM', 'DISPOSE_UNIT_ID', 'STREET_NAME', 'CREATE_TIME',
         'EVENT_SRC_ID', 'INTIME_TO_ARCHIVE_NUM', 'SUB_TYPE_NAME',
         'EVENT_PROPERTY_ID', 'OCCUR_PLACE', 'COMMUNITY_NAME', 'DISPOSE_UNIT_NAME',
         'MAIN_TYPE_NAME', 'MAIN_TYPE_ID']
#g.cnt = 0
sql_2 = connect_sql.Sql('user_info')
sql_1 = connect_sql.Sql('project_data')
df = sql_1.read_database('project_data',head2)
print(len(df))
date = {'year': 2018, 'month': 10, 'day': 30}
df_new = process_data.time_simulation(date,df,head2)
print(len(df_new))
#print(df_new.loc[8])
df = process_data.deletedate(date,df)
print(len(df))
#print(len(df))
#print(df)
#print(len(df))
#print(df)
All_user = sql_2.read_database('user_info',head1)
#print(All_user)

#p = process_data.linshi(df)

#print(p)

# @app.before_request
# def is_login():
#     if request.path == '/login':
#         return None
#     elif not session.get("username"):
#         return redirect('/login')

# @app.before_request
# def before_request():
#     g.cnt = 0

@app.route('/login', methods=['GET','POST'])
def index(name=None):

    if request.method == "POST":
        info1 = request.get_json()
        #print(info1)
        in1 = request.form.get('username')
        #print(in1)
        data1 = process_data.User_Check(All_user, info1)
        #print(data1)
        if data1['answer'] == '0':
            session['username'] = info1['username']
            session['cnt'] = 0
            #print(session.get("username"))
        return jsonify(data1)
    #session.permanent = True
    #app.permanent_session_lifetime = timedelta(minutes=5)
    return render_template('login.html')

@app.route('/charts', methods=['GET','POST'])
def user_login():
    if not session.get("username"):
        return redirect('/login')
    if request.method == 'POST':
        info2 = request.get_json()
        #print(info2)

        if info2['order'] == 1:
            cnt = session['cnt']
            #print(cnt)
            k = len(df)
            print(k)
            print(cnt)
            if cnt < 80:
                df.loc[k] = df_new.loc[cnt]
                #print(df.loc[k])

                session['cnt'] += 1
                if session['cnt'] == 80:
                    session['cnt'] = 80
                    cnt = 80
                #print(k)
            else:
                session['cnt'] = 80
                pass
            data2 = process_data.ABE_sim(df_new,cnt)
            print(data2)
            #print(data2)
            return jsonify(data2)

        elif info2['order'] == 2:
            #print("pp",len(df))
            data2 = process_data.EVENT_PROPERTY(df, info2)
            #print(data2)
            return jsonify(data2)
        elif info2['order'] == 3:
            data2 = process_data.STREET_MAIN_TYPE(df, info2)
            #print(data2)
            return jsonify(data2)
        elif info2['order'] == 4:
            data2 = process_data.Hot_Community(df, info2)
            #print(data2)
            return jsonify(data2)
        elif info2['order'] == 5:
            data2 = process_data.Handling_problems(df, info2)
            print(data2)
            return jsonify(data2)
        elif info2['order'] == 6:
            return jsonify({'name':session['username']})
    if session.get("username"):
        return render_template('home.html')
    # else:
    #     return render_template('login.html')
        #redirect('/')


@app.route('/logout/', methods=['POST','GET'])
def logout():
    session.clear()
    return redirect('/login')
    #return render_template('login.html')






@app.route('/regist', methods=['GET','POST'])
def user_regist():
    #return '<h2>Hello xxx World!</h2>'
    if request.method == "POST":
        user = User()
        user.name=request.form["user_name"]
        print(user.name)
        return redirect(url_for("user_login",username=user.name))

    return render_template('user_regist.html')
#
#
# @app.route('/user/<username>')
# def hello_world1(username):
#     return '<h2>Usersdsds %s</h2>' % username


# app.config['SECRET_KEY'] = os.urandom(24)
# app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)  # 配置7天有效
#
#
# # 设置session
# @app.route('/')
# def set():
#     session['username'] = 'zhangvalue'  # 设置“字典”键值对
#     session.permanent = True  # 设置session的有效时间，长期有效，一个月的时间有效，
#     # 具体看上面的配置时间具体的，没有上面设置的时间就是一个月有效
#     print(app.config['SECRET_KEY'])
#     return 'success'
#
#
# # 读取session
# @app.route('/get')
# def get():
#     # 第一种session获取如果不存在会报错
#     # session['username']
#     # 推荐使用session.get('username')
#     # session.get('username')
#     return session.get('username')
#
#
# # 删除session
# @app.route('/delete/')
# def delete():
#     print(session.get('username'), session.pop('username', None))
#     # 或者 session['username'] = False
#     print(session.get('username'))
#     return 'success'
#
#
# # 清除session中所有数据
# @app.route('/clear')
# def clear():
#     print(session.get('username'))
#     # 清除session中所有数据
#     session.clear
#     print(session.get('username'))
#     return 'success'


if __name__ == '__main__':
    app.run(debug=True)

    # with app.test_request_context():
    #     print(url_for("hello_world", username='fgooo'))
    #     print(url_for("hello_world1", username= 'nmsl'))




# from flask import Flask,request,session,g
#
# app = Flask(__name__)  # type:Flask
#
# @app.before_request
# def auth_demo():
#     g.val = 123
#
# @app.route('/')
# def index():
#     print(g.val)
#     return "Hello World"
#
# if __name__ == '__main__':
#     app.run()


from flask import Flask,session
# import os
# from datetime import timedelta
# app = Flask(__name__)
# app.config['SECRET_KEY'] = os.urandom(24)
# app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)
# # 添加数据到session中
# # 操作session的时候 跟操作字典是一样的。
# # SECRET_KEY


















#session加密处理
# @app.route('/')
# def hello_world():
#     session['username'] = 'zhangsan'
#     # 如果没有指定session的过期时间，那么默认是浏览器关闭就自动结束
#     # 如果设置了session的permanent属性为True，那么过期时间是31天。
#     session.permanent = True
#     return 'Hello World!'
#
# @app.route('/get/')
# def get():
#     # session['username']   如果username不存在则会抛出异常
#     # session.get('username')   如果username不存在会得到 none 不会报错 推荐使用
#     return session.get('username')
#
# @app.route('/delete/')
# def delete():
#     print(session.get('username'))
#     session.pop('username')
#     print(session.get('username'))
#     return 'success'
#
# @app.route('/clear/')
# def clear():
#     print(session.get('username'))
#     # 删除session中的所有数据
#     session.clear()
#     print(session.get('username'))
#     return 'success'
#
# if __name__ == '__main__':
#     app.run(debug=True)